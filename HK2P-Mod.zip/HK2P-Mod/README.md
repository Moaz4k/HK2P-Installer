# HK2P Mod (Android)
Sends HKCoop.prx + HKCoop.cfg to a PS4 over GoldHEN's FTP server (default port 2121) and registers the plugin under [CUSA13632] in /data/GoldHEN/plugins.ini.

Build: open this folder in Android Studio and Run, or push to GitHub (workflow in .github/workflows builds app-debug.apk), or run `gradle assembleDebug` (Gradle 8.9, JDK 17).
Replace the files in app/src/main/assets/ to ship a new plugin version.
