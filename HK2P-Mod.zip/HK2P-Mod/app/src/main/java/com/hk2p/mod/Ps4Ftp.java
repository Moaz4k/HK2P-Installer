package com.hk2p.mod;

import org.apache.commons.net.ftp.FTP;
import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPReply;

import java.io.ByteArrayOutputStream;
import java.io.Closeable;
import java.io.IOException;
import java.io.InputStream;

/** Small wrapper around commons-net FTPClient for GoldHEN's FTP server. */
final class Ps4Ftp implements Closeable {
    private final FTPClient c = new FTPClient();

    Ps4Ftp(String host, int port) throws IOException {
        c.setConnectTimeout(8000);
        c.setDefaultTimeout(20000);
        c.connect(host, port);
        c.setSoTimeout(20000);
        if (!FTPReply.isPositiveCompletion(c.getReplyCode())) {
            throw new IOException("Server refused connection: " + reply());
        }
        if (!c.login("anonymous", "anonymous")) {
            throw new IOException("Login refused: " + reply());
        }
        c.setFileType(FTP.BINARY_FILE_TYPE);
        c.enterLocalPassiveMode();
    }

    String reply() { return c.getReplyString() == null ? "" : c.getReplyString().trim(); }

    void mkdir(String dir) throws IOException { c.makeDirectory(dir); } // fails harmlessly if it exists

    void upload(String remote, InputStream in) throws IOException {
        if (!c.storeFile(remote, in)) throw new IOException("Upload failed for " + remote + ": " + reply());
    }

    void uploadBytes(String remote, byte[] data) throws IOException {
        upload(remote, new java.io.ByteArrayInputStream(data));
    }

    /** Returns file bytes, or null if the file does not exist. */
    byte[] download(String remote) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        if (c.retrieveFile(remote, out)) return out.toByteArray();
        if (missing()) return null;
        throw new IOException("Download failed for " + remote + ": " + reply());
    }

    /** Returns true if deleted, false if it did not exist. */
    boolean delete(String remote) throws IOException {
        if (c.deleteFile(remote)) return true;
        if (missing()) return false;
        throw new IOException("Delete failed for " + remote + ": " + reply());
    }

    private boolean missing() {
        int code = c.getReplyCode();
        return code == 550 || code == 450;
    }

    @Override public void close() {
        try { if (c.isConnected()) { try { c.logout(); } catch (IOException ignored) {} c.disconnect(); } }
        catch (IOException ignored) {}
    }
}
