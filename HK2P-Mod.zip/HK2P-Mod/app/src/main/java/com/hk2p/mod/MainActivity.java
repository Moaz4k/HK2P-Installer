package com.hk2p.mod;

import android.content.SharedPreferences;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends AppCompatActivity {
    private static final String TITLE_ID = "CUSA13632";
    private static final String GH = "/data/GoldHEN";
    private static final String PLUGINS_DIR = GH + "/plugins";
    private static final String PRX_REMOTE = PLUGINS_DIR + "/HKCoop.prx";
    private static final String CFG_REMOTE = GH + "/HKCoop.cfg";
    private static final String LOG_REMOTE = GH + "/HKCoop.log";
    // GoldHEN reads plugins.ini (with an "s"). plugin.ini is only used as a fallback if that is what exists.
    private static final String INI_MAIN = GH + "/plugins.ini";
    private static final String INI_ALT = GH + "/plugin.ini";
    private static final int MAX_LOG_CHARS = 200_000;

    private interface Job { void run(Ps4Ftp ftp) throws Exception; }

    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private EditText ipInput, portInput;
    private TextView status;
    private ProgressBar progress;
    private Button sendBtn, viewLogBtn, delLogBtn, removeBtn;
    private SharedPreferences prefs;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("hk2p", MODE_PRIVATE);
        ipInput = findViewById(R.id.ipInput);
        portInput = findViewById(R.id.portInput);
        status = findViewById(R.id.status);
        progress = findViewById(R.id.progress);
        sendBtn = findViewById(R.id.sendBtn);
        viewLogBtn = findViewById(R.id.viewLogBtn);
        delLogBtn = findViewById(R.id.delLogBtn);
        removeBtn = findViewById(R.id.removeBtn);
        ipInput.setText(prefs.getString("ip", ""));
        portInput.setText(prefs.getString("port", "2121"));

        sendBtn.setOnClickListener(v -> run("Sending the mod...", this::install));
        viewLogBtn.setOnClickListener(v -> run("Reading log...", this::viewLog));
        delLogBtn.setOnClickListener(v -> run("Deleting log...", ftp ->
                log(ftp.delete(LOG_REMOTE) ? "Log file deleted." : "There is no log file.")));
        removeBtn.setOnClickListener(v -> new AlertDialog.Builder(this)
                .setTitle("Remove the mod?")
                .setMessage("This deletes HKCoop.prx and HKCoop.cfg from the PS4 and removes its entry from plugins.ini.")
                .setPositiveButton("Remove", (d, w) -> run("Removing the mod...", this::uninstall))
                .setNegativeButton("Cancel", null)
                .show());
    }

    @Override protected void onDestroy() { super.onDestroy(); executor.shutdownNow(); }

    // ---------------- jobs ----------------

    private void install(Ps4Ftp ftp) throws Exception {
        ftp.mkdir(PLUGINS_DIR);
        try (InputStream in = getAssets().open("HKCoop.prx")) { ftp.upload(PRX_REMOTE, in); }
        log("Sent " + PRX_REMOTE);
        try (InputStream in = getAssets().open("HKCoop.cfg")) { ftp.upload(CFG_REMOTE, in); }
        log("Sent " + CFG_REMOTE);

        String iniPath = INI_MAIN;
        byte[] raw = ftp.download(INI_MAIN);
        if (raw == null) {
            byte[] alt = ftp.download(INI_ALT);
            if (alt != null) { raw = alt; iniPath = INI_ALT; }
        }
        String old = raw == null ? "" : new String(raw, StandardCharsets.UTF_8);
        String updated = IniEditor.addPlugin(old, TITLE_ID, PRX_REMOTE);
        if (raw != null && updated.equals(old)) {
            log(iniPath + " already contains the plugin.");
        } else {
            if (raw != null) ftp.uploadBytes(iniPath + ".bak", raw); // backup before editing
            ftp.uploadBytes(iniPath, updated.getBytes(StandardCharsets.UTF_8));
            log("Updated " + iniPath + " ([" + TITLE_ID + "] entry added).");
        }
        log("\nDone. Start the game (v1.00, " + TITLE_ID + ") now.");
    }

    private void uninstall(Ps4Ftp ftp) throws Exception {
        log(ftp.delete(PRX_REMOTE) ? "Deleted HKCoop.prx" : "HKCoop.prx was not there");
        log(ftp.delete(CFG_REMOTE) ? "Deleted HKCoop.cfg" : "HKCoop.cfg was not there");
        for (String ini : new String[]{INI_MAIN, INI_ALT}) {
            byte[] raw = ftp.download(ini);
            if (raw == null) continue;
            String old = new String(raw, StandardCharsets.UTF_8);
            String updated = IniEditor.removePlugin(old, TITLE_ID, PRX_REMOTE);
            if (!updated.equals(old)) {
                ftp.uploadBytes(ini, updated.getBytes(StandardCharsets.UTF_8));
                log("Removed the entry from " + ini);
            }
        }
        log("\nMod removed.");
    }

    private void viewLog(Ps4Ftp ftp) throws Exception {
        byte[] raw = ftp.download(LOG_REMOTE);
        String text;
        if (raw == null) {
            text = "There is no log file.";
            log(text);
        } else {
            text = new String(raw, StandardCharsets.UTF_8);
            if (text.length() > MAX_LOG_CHARS) text = "[... earlier part cut ...]\n" + text.substring(text.length() - MAX_LOG_CHARS);
            if (text.trim().isEmpty()) text = "(the log file is empty)";
            log("Log loaded (" + raw.length + " bytes).");
        }
        final String shown = text;
        runOnUiThread(() -> showText("HKCoop.log", shown));
    }

    // ---------------- helpers ----------------

    private void run(String busy, Job job) {
        final String ip = ipInput.getText().toString().trim();
        final int port;
        try {
            port = Integer.parseInt(portInput.getText().toString().trim());
            if (ip.isEmpty() || port < 1 || port > 65535) throw new NumberFormatException();
        } catch (NumberFormatException e) {
            status.setText("Enter a valid PS4 IP address and port (e.g. 192.168.1.20 and 2121).");
            return;
        }
        prefs.edit().putString("ip", ip).putString("port", String.valueOf(port)).apply();
        status.setText("");
        setBusy(true);
        log(busy);
        executor.execute(() -> {
            try (Ps4Ftp ftp = new Ps4Ftp(ip, port)) {
                job.run(ftp);
            } catch (Exception e) {
                log("\nERROR: " + e.getMessage()
                        + "\nCheck the IP/port, that GoldHEN's FTP server is on, and that the phone is on the same network.");
            } finally {
                runOnUiThread(() -> setBusy(false));
            }
        });
    }

    private void setBusy(boolean busy) {
        progress.setVisibility(busy ? View.VISIBLE : View.INVISIBLE);
        for (Button b : new Button[]{sendBtn, viewLogBtn, delLogBtn, removeBtn}) b.setEnabled(!busy);
    }

    private void log(String line) {
        runOnUiThread(() -> status.append(line + "\n"));
    }

    private void showText(String title, String text) {
        TextView tv = new TextView(this);
        tv.setText(text);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextSize(12);
        tv.setTextIsSelectable(true);
        int p = (int) (16 * getResources().getDisplayMetrics().density);
        tv.setPadding(p, p, p, p);
        ScrollView sv = new ScrollView(this);
        sv.addView(tv);
        new AlertDialog.Builder(this).setTitle(title).setView(sv).setPositiveButton("Close", null).show();
    }
}
