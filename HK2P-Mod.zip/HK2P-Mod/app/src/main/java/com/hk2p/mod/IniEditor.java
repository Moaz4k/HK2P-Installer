package com.hk2p.mod;

import java.util.ArrayList;
import java.util.List;

/** Adds/removes a plugin path under a [TITLEID] section of GoldHEN's plugins.ini. Pure Java, no Android deps. */
final class IniEditor {
    private IniEditor() {}

    static String addPlugin(String text, String section, String path) {
        String nl = text.contains("\r\n") ? "\r\n" : "\n";
        List<String> lines = lines(text);
        String header = "[" + section + "]";
        int last = -1; // last matching section header
        for (int i = 0; i < lines.size(); i++) {
            if (!lines.get(i).trim().equalsIgnoreCase(header)) continue;
            int end = sectionEnd(lines, i);
            for (int j = i + 1; j < end; j++) {
                if (lines.get(j).trim().equals(path)) return text; // already installed
            }
            last = i;
        }
        if (last >= 0) {
            int end = sectionEnd(lines, last);
            int at = last + 1;
            for (int j = last + 1; j < end; j++) if (!lines.get(j).trim().isEmpty()) at = j + 1;
            lines.add(at, path);
        } else {
            while (!lines.isEmpty() && lines.get(lines.size() - 1).trim().isEmpty()) {
                lines.remove(lines.size() - 1);
            }
            if (!lines.isEmpty()) lines.add("");
            lines.add(header);
            lines.add(path);
        }
        return join(lines, nl);
    }

    static String removePlugin(String text, String section, String path) {
        String nl = text.contains("\r\n") ? "\r\n" : "\n";
        List<String> lines = lines(text);
        String header = "[" + section + "]";
        boolean changed = false;
        for (int i = lines.size() - 1; i >= 0; i--) {
            if (!lines.get(i).trim().equalsIgnoreCase(header)) continue;
            int end = sectionEnd(lines, i);
            boolean empty = true;
            for (int j = end - 1; j > i; j--) {
                if (lines.get(j).trim().equals(path)) { lines.remove(j); end--; changed = true; }
            }
            for (int j = i + 1; j < end; j++) if (!lines.get(j).trim().isEmpty()) empty = false;
            if (empty) {
                for (int j = end - 1; j >= i; j--) lines.remove(j);
                changed = true;
            }
        }
        if (!changed) return text;
        while (!lines.isEmpty() && lines.get(lines.size() - 1).trim().isEmpty()) {
            lines.remove(lines.size() - 1);
        }
        return join(lines, nl);
    }

    private static int sectionEnd(List<String> lines, int header) {
        int j = header + 1;
        while (j < lines.size() && !lines.get(j).trim().startsWith("[")) j++;
        return j;
    }

    private static List<String> lines(String text) {
        List<String> out = new ArrayList<>();
        if (text.isEmpty()) return out;
        for (String s : text.split("\r?\n", -1)) out.add(s);
        if (out.get(out.size() - 1).isEmpty()) out.remove(out.size() - 1);
        return out;
    }

    private static String join(List<String> lines, String nl) {
        if (lines.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (String l : lines) sb.append(l).append(nl);
        return sb.toString();
    }
}
